﻿using POI.Application.Base.Result;
using POI.Application.Base.Service;
using POI.Domain.UnitOfWorks;

namespace $rootnamespace$
{
    public class $safeitemname$ : IBusinessService<$safeitemname$.Request, $safeitemname$.Response>
    {
        private readonly IUnitOfWork _unitOfWork;
        #region constructor
        public $safeitemname$(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Request & Response

        public class Request
        {
        }

        public class Response
        {
        }


        #endregion

        public async Task<Result<Response>> ExecuteAsync(Request request)
        {

            //TODO Write your business logic here

            return null;
        }
    }
}
