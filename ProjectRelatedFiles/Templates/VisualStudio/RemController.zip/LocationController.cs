using Microsoft.AspNetCore.Mvc;
using POI.Application.Base.Service;
using POI.Domain.UnitOfWorks;

namespace $rootnamespace$;


[ApiController]
[Route("api/v1/[controller]")]
public class $safeitemname$ : BaseController
{
    private readonly BaseBusinessService _baseService;
    private readonly IUnitOfWork _unitOfWork;

    public $safeitemname$(BaseBusinessService baseService, IUnitOfWork unitOfWork)
    {
        _baseService = baseService;
        _unitOfWork = unitOfWork;
    }
    
    [HttpGet("Test/{id}")]
    public async Task<IActionResult> GetPoiCatalogById(int Id)
    {
        // var response = await _baseService.InvokeAsync<UpdatePoiCatalog, UpdatePoiCatalog.Request, UpdatePoiCatalog.Response>(request);
        //
        // if (!response.IsSuccess)
        //     return BadRequest(response);
        //
        // return Ok(response);
        
        throw new NotImplementedException();
    }
}